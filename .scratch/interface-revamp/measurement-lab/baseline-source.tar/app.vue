<template>
  <NuxtPage />
</template>
